import 'package:flutter/material.dart';
import 'dashboard_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final user = TextEditingController();
  final pass = TextEditingController();
  bool hide = true;

  @override
  void dispose() { user.dispose(); pass.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)), child: Image.asset('assets/images/marbef_logo.jpg', height: 105, fit: BoxFit.contain)),
      const SizedBox(height: 28), const Text('Bem-vindo!', textAlign: TextAlign.center, style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: Color(0xFF20247F))),
      const SizedBox(height: 6), const Text('Entre na sua conta para gerir o negócio.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 26), const Text('Utilizador', style: TextStyle(fontWeight: FontWeight.w600)), const SizedBox(height: 8),
      TextField(controller: user, decoration: const InputDecoration(prefixIcon: Icon(Icons.person_outline), hintText: 'Nome de utilizador')),
      const SizedBox(height: 16), const Text('Palavra-passe', style: TextStyle(fontWeight: FontWeight.w600)), const SizedBox(height: 8),
      TextField(controller: pass, obscureText: hide, decoration: InputDecoration(prefixIcon: const Icon(Icons.lock_outline), hintText: 'Palavra-passe', suffixIcon: IconButton(onPressed: () => setState(() => hide = !hide), icon: Icon(hide ? Icons.visibility : Icons.visibility_off)))),
      const SizedBox(height: 24), ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF20247F), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const DashboardScreen())), child: const Text('ENTRAR', style: TextStyle(fontWeight: FontWeight.bold))),
      const SizedBox(height: 18), const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.wifi_off, size: 17, color: Color(0xFF20247F)), SizedBox(width: 7), Text('Preparado para funcionamento offline', style: TextStyle(fontSize: 12, color: Colors.black54))]),
      const SizedBox(height: 24), const Text('MARBEF Services SU, Lda.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF20247F), fontWeight: FontWeight.w600)),
    ]))))),
  );
}

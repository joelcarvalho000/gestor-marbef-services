import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  static const navy = Color(0xFF20247F);
  static const red = Color(0xFFED1B24);

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.point_of_sale, 'Vendas', 'Registar vendas'),
      (Icons.inventory_2_outlined, 'Stock', 'Produtos'),
      (Icons.people_outline, 'Clientes', 'Histórico'),
      (Icons.account_balance_wallet_outlined, 'Despesas', 'Registar gastos'),
      (Icons.bar_chart, 'Relatórios', 'Ver resultados'),
      (Icons.badge_outlined, 'Funcionários', 'Gerir equipa'),
      (Icons.receipt_long, 'Recibos', 'Emitir recibos'),
      (Icons.settings_outlined, 'Definições', 'Configurar sistema'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('MARBEF SERVICES', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)), actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))]),
      drawer: Drawer(child: SafeArea(child: Column(children: [Container(width: double.infinity, color: navy, padding: const EdgeInsets.all(18), child: Column(children: [Image.asset('assets/images/marbef_logo.jpg', height: 76), const SizedBox(height: 12), const Text('Gestor Marbef Services', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))])), ...items.map((e) => ListTile(leading: Icon(e.$1, color: navy), title: Text(e.$2), onTap: () => Navigator.pop(context))), const Spacer(), const ListTile(leading: Icon(Icons.logout, color: red), title: Text('Sair'))]))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Painel principal', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: navy)),
        const SizedBox(height: 5), const Text('Resumo do teu negócio', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 16),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFE8F4EC), borderRadius: BorderRadius.circular(14)), child: const Row(children: [Icon(Icons.cloud_off, color: Color(0xFF237A43)), SizedBox(width: 10), Expanded(child: Text('Modo offline: os dados ficam guardados neste dispositivo.', style: TextStyle(color: Color(0xFF205D37))))])),
        const SizedBox(height: 16),
        GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.55, children: const [
          _Metric(title: 'Vendas de hoje', value: '0 MT', icon: Icons.shopping_cart, color: navy),
          _Metric(title: 'Lucro do mês', value: '0 MT', icon: Icons.trending_up, color: red),
          _Metric(title: 'Produtos', value: '0', icon: Icons.inventory_2, color: navy),
          _Metric(title: 'Clientes', value: '0', icon: Icons.groups, color: red),
        ]),
        const SizedBox(height: 22), const Text('Menu principal', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: navy)),
        const SizedBox(height: 10),
        GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: items.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.5), itemBuilder: (context, i) => Card(elevation: 0, color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15), side: const BorderSide(color: Color(0xFFE1E5F2))), child: InkWell(borderRadius: BorderRadius.circular(15), onTap: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Módulo ${items[i].$2}: próxima etapa de desenvolvimento.'))), child: Padding(padding: const EdgeInsets.all(12), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(items[i].$1, color: i.isEven ? navy : red, size: 30), const SizedBox(height: 8), Text(items[i].$2, style: const TextStyle(fontWeight: FontWeight.bold, color: navy)), Text(items[i].$3, style: const TextStyle(fontSize: 11, color: Colors.black54))]))))),
        const SizedBox(height: 16), const Center(child: Text('MARBEF Services SU, Lda. • MT', style: TextStyle(color: Colors.black45, fontSize: 12))),
      ]),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.title, required this.value, required this.icon, required this.color});
  final String title, value; final IconData icon; final Color color;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFFE1E5F2))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Icon(icon, color: color, size: 25), Text(title, style: const TextStyle(fontSize: 12, color: Colors.black54)), Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color))]));
}

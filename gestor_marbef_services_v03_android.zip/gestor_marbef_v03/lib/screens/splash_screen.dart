import 'package:flutter/material.dart';
import 'login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(
      width: double.infinity,
      decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF20247F), Color(0xFF10164D)])),
      child: SafeArea(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(padding: const EdgeInsets.all(12), margin: const EdgeInsets.symmetric(horizontal: 34), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: Image.asset('assets/images/marbef_logo.jpg', fit: BoxFit.contain)),
        const SizedBox(height: 28), const Text('GESTOR MARBEF SERVICES', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold, letterSpacing: 1)),
        const SizedBox(height: 8), const Text('Uma plataforma. Vários negócios. Controlo total.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 13)),
        const SizedBox(height: 36), const CircularProgressIndicator(color: Color(0xFFED1B24)),
      ])),
    ),
  );
}
